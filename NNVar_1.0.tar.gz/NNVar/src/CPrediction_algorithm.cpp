#include"../inst/include/CPrediction_algorithm.h"

CPrediction_algorithm ::CPrediction_algorithm (const Struct::CMatDouble & X,
                                               unsigned int & ep,
                                               unsigned int & eh)     throw (nsUtil::CException)
{

  // Variables du modèle de prédiction
  p = ep;
  h = eh;

  // Dimensions de la matrice d'entée
   Nb_Ln = X[0].size () ;
   Nb_Cl = X.size ();
    
    // Vérifier les entrées
    if (Nb_Ln == 0 or Nb_Cl == 0)
        throw nsUtil::CException  ("The input data is empty",
                                   nsUtil::KVectNullSize);
    
    // Vérifier la valeur de p
    if (p == 0 or h == 0)
        throw nsUtil::CException  ("The value of the parameters must be greater than 0",
                                   nsUtil::KVectNullSize);

  // Vérifier la valeur de p
   if (Nb_Ln < p)
       throw nsUtil::CException  ("the value of p must be less than the number of lignes for the Var(p) Model",
                                  nsUtil::KVectNullSize);

    Predict = X;
    Predict.Interpol ();
}

