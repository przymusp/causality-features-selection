#include "../inst/include/CGrangerCausality.h"
#include "../inst/include/Tests.h"
#include "../inst/include/Ftable.h"
#include "../inst/include/FDIST.h"


using namespace MatrixOperations;
using namespace Struct;
using namespace std;

CVDouble VECbivar (CMatDouble  M, unsigned lag, bool d /* = false */)
{
    CMatDouble initials;
    CMatDouble residus;
    CMatDouble Alpha;
    vector <int> orders, testCoint;
    CMatDouble Test;
    unsigned nlins, i, k;
    CMatDouble B, A, Present, Beta, pCible;
    CVDouble  pBeta, one, trend, Aecorrection, Becorrection, Conf;
    
    unsigned nbreCol = M.size(), p = lag;
    unsigned nbreLn = M[0].size();
    double SSE;
    
    Conf.resize(nbreCol);
    Alpha.resize(nbreCol);
    orders.reserve (nbreCol);
    
    for (auto Vect:M)
    {
        orders.push_back (order (Vect, p));
    }
 
    int maxOrder = 0;

    if (d)
    {
        for (auto & in:orders)
            if (in > maxOrder)
                maxOrder = in;
        
        initials.resize (nbreCol);
        
        for (unsigned i(0) ; i < nbreCol ; ++i)
        {
            initials[i].resize (maxOrder);
            
            for (int m (0) ; m < orders[i] ; ++m)
            {
                for (auto it = M[i].end () -1;it != M[i].begin ();--it)
                    *it -= *(it-1) ;
                initials[i][m] = M[i][0];
                M[i].erase (M[i].begin ());
            }
            
            if (orders[i] < maxOrder)
                for (unsigned l(orders[i]) ; l < maxOrder ; ++l)
                {
                    initials[i][l] = M[i][0];
                    M[i].erase (M[i].begin ());
                }
        }
    
    // Nombre de lignes après différentiation
    nlins = nbreLn - maxOrder;
    }
    else
        nlins = nbreLn;
    
    for (i = p ; i < nlins ; i++) {
        one.push_back (1);
        trend.push_back (i-p+1);
    }
    A.reserve (nbreCol * lag + 2);
    B.reserve (nbreCol * lag + 2);
    B.push_back (one);
    A.push_back (one);
    //B.push_back (trend);
    //A.push_back (trend);
    
    pCible.resize (nbreCol);
    
    
    for (auto vect:M)
    {
        P_Part (vect, Present, B, lag);
        Pr_Part (vect, A, lag);
    }
    
    
    for (i = 0 ; i < nbreCol ; ++i)
    {
        regression (B , Present[i], pBeta);
        MultCVDouble (B, pBeta, pCible[i]);
        pBeta.clear();
    } // END i
    
    unsigned n2 = B[0].size ();
    
    for (i = 0 ; i < nbreCol ; ++i)
    {
        SSE = 0;
        for (unsigned m = 0 ; m < Present[i].size() ; m++)
            SSE += pow (pCible[i][m] - Present[i][m], 2);
        Conf[i] = SSE;
    }
    
    one.clear ();
    trend.clear ();
    pCible.clear ();
    Beta.clear ();
    pBeta. clear ();
    A.clear ();
    B.clear ();
    Present.clear ();
    // Integration
    int kl = 0, ind = 0;
    int n;
    
    /* for (auto & vec:M)
     {
     if (orders[kl] < maxOrder)
     for (n = maxOrder - 1 ; n >= orders[kl] ; --n) {
     vec.insert (vec.begin (), initials[kl][n]);
     }
     
     if (orders[kl] > 0)
     for (n = orders[kl] - 1 ; n >= 0 ; --n)
     {
     vec.insert (vec.begin (), initials[kl][n]);
     ind = 0;
     for (auto it = vec.begin () + 1 ; it != vec.end () ; ++it, ind++) {
     *it += *(it-1) ;
     }
     }
     kl = kl + 1;
     }*/
    
    orders.clear();
    //testCoint.clear();
    //residus.clear();
    initials.clear();
    
    return Conf;
}
/************************************/
CausalityTest::CausalityTest (Rcpp::NumericVector  ts1_,
                              Rcpp::NumericVector  ts2_, int lag_, bool d /* = false */) throw (nsUtil::CException){
    
    // Checking if the lag value is positif
    if (lag_ < 0)
        throw nsUtil::CException ("The lag value is incorrect", nsUtil::KErrArg);
    
    // 0 is the default argument attributed to the lag value length(tS)^1/3
    if (lag_ == 0)
        lag = 1;
    else lag  = lag_;
    
    for (const auto val:ts1_)
        ts1.push_back (val);
    
    for (const auto val:ts2_)
        ts2.push_back (val);
    
    if (ts1.size() != ts2.size())
        throw nsUtil::CException ("Time series have not the same size", nsUtil::KErrArg);
    
    
    // variables
    unsigned nl (ts1.size ());
    double RSS1(0), RSS0(0);
    
    CVDouble VECT;
    CMatDouble M (1);
    //M.reserve(1);
    M[0] = ts1;
    
   // cout << " Univariate Model \n:" << M << endl;
    
    /* the VAR model of the system (v1) */
    VECT = VECbivar(M, lag, d);
    RSS0 = VECT[0];
    
    /* the VAR model of the system (v1,v2) */
    M.push_back(ts2);
    VECT = VECbivar(M, lag, d);
    RSS1 = VECT[0];
    
    int T = nl - lag;
    // F test
    Ftest = ((RSS0 - RSS1) / lag) / (RSS1 / (T - 2*lag - 1));
    
    // p-value of the F-test
    p_value = getPvalue (Ftest , lag , T - 2*lag - 1);
    
    if (lag <= 20 and T - 2*lag - 1 <= 100)
        criticTest = ftable[T - 2*lag - 2][lag];
    else if (lag > 20 and T - 2*lag - 1 <= 100)
        criticTest = ftable[T - 2*lag - 2][20];
    else if (lag <= 20 and T - 2*lag - 1 > 100)
        criticTest = ftable[100][lag];
    else if (lag > 20 and T - 2*lag - 1 > 100)
        criticTest = ftable[100][20];
}
void CausalityTest::summary ()
{
    std::cout <<  "        Test of causality" << "\n";
    std::cout <<  "------------------------------------------------\n\n";
    std::cout <<  "The lag parameter: p = "<< lag << "\n";
    std::cout <<  "The value of the F-test: "<< Ftest << "\n";
    std::cout <<  "The p_value of the F-test: "<< p_value << "\n";
    std::cout <<  "The critical value with 5% of risk:: "<< criticTest <<"\n";
    
    if (Ftest > criticTest)
        std::cout <<  "----------> There is causality \n";
    else
        std::cout <<  "----------> There is no causality \n";
    std::cout <<  "------------------------------------------------"<< "\n";
}
double CausalityTest::get_p_value () {
    return p_value;
}
double CausalityTest::get_F_test () {
    return Ftest;
}


