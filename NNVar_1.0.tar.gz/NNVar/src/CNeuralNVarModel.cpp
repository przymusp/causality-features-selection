

#include "../inst/include/CNeuralNVarModel.h"


using namespace MatrixOperations;
using namespace Struct;
using namespace std;
CNeuralNVarModel::CNeuralNVarModel(const CMatDouble & X,
                                   unsigned int & ep,
                                   unsigned int & eh,
                                   const vector<int> & sizeOfLayers,
                                   unsigned int iterations):CPrediction_algorithm::CPrediction_algorithm (X, ep, eh),
    sizeOfLayers_ (sizeOfLayers),
    numLayers_ (sizeOfLayers.size ()+2),
    iterations_ (iterations)
{
    
    mpl.resize (Nb_Cl);
    forecasts.resize (Nb_Cl);
    for (CVDouble & vec:forecasts)
        vec.reserve (h);
    
    vector<double>  VMin, VMax;
    double Min, Max;
    
    // Normalisation
    for (auto Vect = Predict.begin () ; Vect != Predict.end () ; ++Vect)
    {
        Min = Vect->Min ();
        Max = Vect->Max ();
        VMin.push_back  (Min);
        VMax.push_back  (Max);
        
        for (auto it = Vect->begin () ; it != Vect->end () ; ++it)
            (*it) = ((*it) - Min) / (Max - Min);
        
    }
    
    NNVar ();
    
    // Denormalisation
    for (unsigned ip = 0 ; ip < Nb_Cl ; ++ip)
    {
        for (auto & val:Predict[ip])
            val = val * (VMax[ip] - VMin[ip]) + VMin[ip];
    }
    
    for (unsigned ij = 0 ; ij < Nb_Cl ; ++ij)
        for (unsigned ip = Nb_Ln ; ip < Nb_Ln + h; ++ip)
            forecasts[ij].push_back (Predict[ij][ip]);
}

void CNeuralNVarModel::NNVar ()
{
    unsigned int i, j;
    CMatDouble A, AF, Futurs, Present;
    CVDouble one;
    
    if (sizeOfLayers_.size() == 0)
    {
        sizeOfLayers_ = {1,10,1};
        numLayers_ = 3;
    }
    
    // the constant attribut
    //for (i = 1 ; i <= Nb_Ln - p ; ++i)
      //  one.push_back (0.5);
    
    // Building the training matrix
    for (i = 0  ; i < Nb_Cl ; i++)
        P_Part (Predict[i], Present, A, p);
   // A.push_back (one);
    one.clear();
    
    /******************* The Training Step of the neural net **********************/
    CVDouble Resout;
    int c = 0;
    int numInputs = A.size ();
    int numOutput = 1;
    //sizeOfLayers_[0] = numInputs;
    sizeOfLayers_.insert (sizeOfLayers_.begin(),  numInputs);
    sizeOfLayers_.push_back (numOutput);
    
    // Build for each attibut a neural net
    /*vector <shared_ptr <MultiLayerPerceptron>> mpl0(Nb_Cl);
    mpl = mpl0;
    mpl0.clear ();*/
    
    // Train each neural net
    //for (const auto &vec:Present)
    
        mpl[0] = shared_ptr <MultiLayerPerceptron> (new MultiLayerPerceptron (numLayers_, sizeOfLayers_));
        mpl[0]->Run (Present[0], A, iterations_, Resout);
        //++c;
    
    
    /******************* the Simulation/Prediction Step **********************/
    for (j = 0 ; j < h ; j++)
    {
        Futurs.clear ();
        AF.clear();
        Resout.clear();
        //one.clear();
        
        // Simulation matrix
        for (i = 0  ; i < Nb_Cl ; i++)
            Pr_Part (Predict[i], AF, p);
        
        // Add the constant vector
        //one.push_back(0.5);
        //for (i = 1 ; i <= AF[0].size() ; ++i)
          //  one.push_back (0.5);
        
       // AF.push_back (one);
        
        // Simulate the networks for each time series
        c = 0;
        //for (const auto &vec:Present)
        //{
            mpl[c]->Test (Present[0], AF, Resout);
            Futurs.push_back(Resout);
            c++;
        //}
        Predict[0].push_back (Futurs[0].back ());
        for (i = 1 ; i < Nb_Cl ; i++)
            Predict[i].push_back (0);
    }
    
}
/******************* the Simulation **********************/
CVDouble CNeuralNVarModel::simulate (const Struct::CMatDouble & M)
{
    CMatDouble F, A, B, Res, present;
    CVDouble result;
    
    Res = M;
    
    vector<double>  VMin, VMax;
    double Min, Max;
    
    // Normalisation
    for (auto Vect = Res.begin () ; Vect != Res.end () ; ++Vect)
    {
        Min = Vect->Min ();
        Max = Vect->Max ();
        VMin.push_back  (Min);
        VMax.push_back  (Max);
        
        for (auto it = Vect->begin () ; it != Vect->end () ; ++it)
            (*it) = ((*it) - Min) / (Max - Min);
        
    }
    
    
    if (Res.size () == Nb_Cl and Res[0].size () >= p)
    {
        for (auto vec:Res)
            P_Part (vec, present, B, p);
        
        for (auto vec:Res)
            Pr_Part (vec, A, p);
        
        Res.clear ();
        
        // Simulate the networks for each time series
        mpl[0]->Test (present[0], A, result);
        Res.push_back(result);
        
    }
    // Denormalisation
    for (unsigned ip = 0 ; ip < Nb_Cl ; ++ip)
    {
        for (auto & val:Res[ip])
            val = val * (VMax[ip] - VMin[ip]) + VMin[ip];
    }
    
    for (auto & val:result)
    val = val * (VMax[0] - VMin[0]) + VMin[0];
    
    return result;
    
}

/******************* the Simulation **********************/
void CNeuralNVarModel::train (const Struct::CMatDouble & M)
{
    CMatDouble F, B, present, Res;
    CVDouble result;
    
    Res = M;
    
    double Min, Max;
    
    // Normalisation
    for (auto Vect = Res.begin () ; Vect != Res.end () ; ++Vect)
    {
        Min = Vect->Min ();
        Max = Vect->Max ();
        for (auto it = Vect->begin () ; it != Vect->end () ; ++it)
            (*it) = ((*it) - Min) / (Max - Min);
    }
    
    
    if (Res.size () == Nb_Cl and Res[0].size () >= p)
    {
        //for (int i = 0  ; i < Nb_Cl ; i++)
        for (auto vec:Res)
            P_Part (vec, present, B, p);
        
        // Simulate the networks for each time series
        int c = 0;
        //for (const auto &vec:present)
        //{
            mpl[c]->Train (present[0], B);
            //Res.push_back(result);
          //  c++;
        //}
    }
}
