
#include <cstdlib>
#include <cmath>
#include <algorithm>

#include "../inst/include/CMultiLayerPerceptron.h"
#include "../inst/include/Operateurs.h"

using namespace Struct;
using namespace std;

void InitializeRandoms()
{
  //  srand( (unsigned)time( NULL ) );
  srand(4711);
}

int RandomEqualINT(int Low, int High)
{
  return rand() % (High-Low+1) + Low;
}

double RandomEqualREAL(double Low, double High)
{
  return ((double) rand() / RAND_MAX) * (High-Low) + Low;
}

MultiLayerPerceptron::MultiLayerPerceptron(int nl,  const vector<int> &npl) :
  nNumLayers(0),
  pLayers(0),
  dMSE(0.0),
  dMAE(0.0),
  dEta(0.25),
  dAlpha(0.9),
  dGain(1.0),
  dAvgTestError(0.0)
{
  int i,j;

  /* --- creation des couches */
  nNumLayers = nl;
  pLayers    = new Layer[nl];

  /* --- init des couches */
  for ( i = 0; i < nNumLayers; i++ )
    {
      /* --- creation des neurones */
      pLayers[i].nNumNeurons = npl[i];
      pLayers[i].pNeurons    = new Neuron[ npl[i] ];

      /* --- init des neurones */
      for( j = 0; j < npl[i]; j++ )
    {
      pLayers[i].pNeurons[j].x  = 1.0;

      //std::cout << pLayers[i].pNeurons[j].x << std::endl;

      pLayers[i].pNeurons[j].e  = 0.0;

      if(i > 0)
        {
          pLayers[i].pNeurons[j].w     = new double[ npl[i-1] ];
          pLayers[i].pNeurons[j].dw    = new double[ npl[i-1] ];
          pLayers[i].pNeurons[j].wsave = new double[ npl[i-1] ];
        }
      else
        {
          pLayers[i].pNeurons[j].w     = NULL;
          pLayers[i].pNeurons[j].dw    = NULL;
          pLayers[i].pNeurons[j].wsave = NULL;
        }
    }

    }
}

/**************************************************/
MultiLayerPerceptron::~MultiLayerPerceptron()
{
  int i,j;
  for( i = 0; i < nNumLayers; i++ )
    {
      if ( pLayers[i].pNeurons )
    {
      for( j = 0; j < pLayers[i].nNumNeurons; j++ )
        {
          if ( pLayers[i].pNeurons[j].w )
        delete[] pLayers[i].pNeurons[j].w;
          if ( pLayers[i].pNeurons[j].dw )
        delete[] pLayers[i].pNeurons[j].dw;
          if ( pLayers[i].pNeurons[j].wsave )
        delete[] pLayers[i].pNeurons[j].wsave;
        }
    }
      delete[] pLayers[i].pNeurons;
    }
  delete[] pLayers;
}

/**************************************************/
void MultiLayerPerceptron::RandomWeights()
{
  int i,j,k;
  for( i = 1; i < nNumLayers; i++ )
    {
      for( j = 0; j < pLayers[i].nNumNeurons; j++ )
    {
      for ( k = 0; k < pLayers[i-1].nNumNeurons; k++ )
        {
          pLayers[i].pNeurons[j].w [k]    = RandomEqualREAL(-0.5, 0.5);
          pLayers[i].pNeurons[j].dw[k]    = 0.0;
          pLayers[i].pNeurons[j].wsave[k] = 0.0;
        }
    }
    }
}

/**************************************************/
void MultiLayerPerceptron::SetInputSignal(CVDouble & input)
{
  int i;
  for ( i = 0; i < pLayers[0].nNumNeurons; i++ )
    {
      pLayers[0].pNeurons[i].x = input[i];

    }
}

/**************************************************/
void MultiLayerPerceptron::GetOutputSignal(CVDouble & output)
{
  int i;
  output.clear ();
  output.resize (pLayers[nNumLayers-1].nNumNeurons);
  for ( i = 0; i < pLayers[nNumLayers-1].nNumNeurons; i++ )
    {
      output[i] = pLayers[nNumLayers-1].pNeurons[i].x;
    }
}

/**************************************************/
void MultiLayerPerceptron::SaveWeights()
{
  int i,j,k;
  for( i = 1; i < nNumLayers; i++ )
    for( j = 0; j < pLayers[i].nNumNeurons; j++ )
      for ( k = 0; k < pLayers[i-1].nNumNeurons; k++ )
    pLayers[i].pNeurons[j].wsave[k] = pLayers[i].pNeurons[j].w[k];
}

/**************************************************/
void MultiLayerPerceptron::RestoreWeights()
{
  int i,j,k;
  for( i = 1; i < nNumLayers; i++ )
    for( j = 0; j < pLayers[i].nNumNeurons; j++ )
      for ( k = 0; k < pLayers[i-1].nNumNeurons; k++ )
            pLayers[i].pNeurons[j].w[k] = pLayers[i].pNeurons[j].wsave[k];
}

/***************************************************************************/
/* calculate and feedforward outputs from the first layer to the last      */
void MultiLayerPerceptron::PropagateSignal()
{
  int i,j,k;

  //std::cout << "dMSE: "<< pLayers[nNumLayers-1].pNeurons[0].x << std::endl;

  /* --- la boucle commence avec la seconde couche */
  for (i = 1; i < nNumLayers; i++)
    {
      //for (k = 0 ; k < pLayers[i-1].nNumNeurons ; ++k)
        //    std::cout << pLayers[i-1].pNeurons[k].x << std::endl;
      for (j = 0; j < pLayers[i].nNumNeurons; j++)
        {
            /* --- calcul de la somme ponderee en entree */
            double sum = 0.0;
            for (k = 0 ; k < pLayers[i-1].nNumNeurons ; ++k)
              {
                double out = pLayers[i-1].pNeurons[k].x;
                double w   = pLayers[i  ].pNeurons[j].w[k];
                sum       += w * out;
                //std::cout << "k: " << k << "    " <<out << std::endl;
              }
            /* --- application de la fonction d'activation (sigmoid) */
             pLayers[i].pNeurons[j].x = 1.0 / (1.0 + exp(-dGain * sum));
            //pLayers[i].pNeurons[j].x = sum;
             //cout << w << endl;
        }
    }
}

/**************************************************/
void MultiLayerPerceptron::ComputeOutputError(CVDouble & target)
{
  int  i;
  dMSE = 0.0;
  dMAE = 0.0;
  for( i = 0; i < pLayers[nNumLayers-1].nNumNeurons; i++)
    {
      double x = pLayers[nNumLayers-1].pNeurons[i].x;
      double d = (target[i] - x);

      pLayers[nNumLayers-1].pNeurons[i].e = dGain * x * (1.0 - x) * d;
      //pLayers[nNumLayers-1].pNeurons[i].e = d;

      dMSE += (d * d);
      dMAE += fabs(d);
    }
  /* --- erreur quadratique moyenne */
  dMSE /= (double)pLayers[nNumLayers-1].nNumNeurons;

  /* --- erreur absolue moyenne */
  dMAE /= (double)pLayers[nNumLayers-1].nNumNeurons;
}

/***************************************************************************/
/* backpropagate error from the output layer through to the first layer    */

void MultiLayerPerceptron::BackPropagateError()
{
  int i,j,k;
  /* --- la boucle commence a l'avant derniere couche */
  for( i = (nNumLayers-2); i >= 0; i-- )
    {
      /* --- couche inferieure */
      for( j = 0; j < pLayers[i].nNumNeurons; j++ )
    {
      double x = pLayers[i].pNeurons[j].x;
      double E = 0.0;
      /* --- couche superieure */
      for ( k = 0; k < pLayers[i+1].nNumNeurons; k++ )
        {
          E += pLayers[i+1].pNeurons[k].w[j] * pLayers[i+1].pNeurons[k].e;
        }
      pLayers[i].pNeurons[j].e = dGain * x * (1.0 - x) * E;
    }
    }
}

/***************************************************************************/
/* update weights for all of the neurons from the first to the last layer  */

void MultiLayerPerceptron::AdjustWeights()
{
  int i,j,k;
  /* --- la boucle commence avec la seconde couche */
  for( i = 1; i < nNumLayers; i++ )
    {
      for( j = 0; j < pLayers[i].nNumNeurons; j++ )
    {
      for ( k = 0; k < pLayers[i-1].nNumNeurons; k++ )
        {
          double x  = pLayers[i-1].pNeurons[k].x;
          double e  = pLayers[i  ].pNeurons[j].e;
          double dw = pLayers[i  ].pNeurons[j].dw[k];
          pLayers[i].pNeurons[j].w [k] += dEta * x * e + dAlpha * dw;
          pLayers[i].pNeurons[j].dw[k]  = dEta * x * e;
        }
    }
    }
}

/**************************************************/
void MultiLayerPerceptron::Simulate(CVDouble & input, CVDouble & output, CVDouble & target, bool training)
{

  if(0 == input.size())  return;
  if(0 == target.size()) return;


  /* --- on fait passer le signal dans le reseau */

  SetInputSignal(input);

  PropagateSignal();

   //AdjustWeights();

  GetOutputSignal(output);


  /* --- calcul de l'erreur en sortie par rapport a la cible */
  /*     ce calcul sert de base pour la rÈtropropagation     */
  // ComputeOutputError(target);

  /* --- si c'est un apprentissage, on fait une retropropagation de l'erreur */
  if (training)
    {
      ComputeOutputError(target);
      BackPropagateError();
      AdjustWeights();
      //GetOutputSignal(output);
    }
  //std::cout << "dMSE: "<< pLayers[nNumLayers-1].pNeurons[0].x << std::endl;

}

/**************************************************/
void MultiLayerPerceptron::Predict (CVDouble & input, Struct::CVDouble & output)
{
    if(0 == input.size())  return;

    SetInputSignal(input);
    PropagateSignal();
    GetOutputSignal(output);
}

/**************************************************/

int MultiLayerPerceptron::Train(const CVDouble & target_, const CMatDouble & trainingMatrix)
{
  int count = 0;

  unsigned int Numb = trainingMatrix[0].size ();
  unsigned int ncol = trainingMatrix.size ();

  CVDouble  input (pLayers[0].nNumNeurons);
  CVDouble  output (pLayers[nNumLayers-1].nNumNeurons);
  CVDouble  target (pLayers[nNumLayers-1].nNumNeurons);

  if(0 == input.size()) return 0;
  if(0 == output.size()) return 0;
  if(0 == target.size()) return 0;

 for (unsigned int i = 0 ; i < Numb ; ++i)
    {
    /* --- on le transforme en input/target */
       target[0] = target_[i];
       for (unsigned int j = 0 ; j < ncol ; ++j)
          input[j] = trainingMatrix[j][i];

    /* --- on fait un apprentisage du reseau avec cette ligne*/
        Simulate(input, output, target, true);
        count++;
    }

  input.clear();
  output.clear();
  target.clear();

  return count;
}

/*******************************************************/
int MultiLayerPerceptron::Test(const CVDouble & target_,const CMatDouble & Matrix, CVDouble & Output)
{
  int count = 0;
  unsigned int Numb = Matrix[0].size ();
  unsigned int ncol = Matrix.size ();
  double MinMax;
  Output.resize (Numb);

  CVDouble  input (pLayers[0].nNumNeurons);
  CVDouble  output (pLayers[nNumLayers-1].nNumNeurons);
  CVDouble  target (pLayers[nNumLayers-1].nNumNeurons);

  if(input.size ()  == 0) return 0;
  if(output.size () == 0) return 0;
  if(target.size () == 0) return 0;

  dAvgTestError = 0.0;

  CVDouble cible = target_;
  CMatDouble trainingMatrix = Matrix;

  /* Normalisation du target */
/*  double Min = cible.Min ();
  double Max = cible.Max ();

  if (abs (Max) >= abs (Min))
    {
      MinMax = abs (Max);
      for (auto it = cible.begin () ; it != cible.end () ; ++it)
          (*it) = (*it) / Max;
    }
  else if (abs (Max) < abs (Min))
    {
      MinMax = abs (Min);
      for (auto it = cible.begin () ; it != cible.end () ; ++it)
          (*it) = (*it) / Min;
    }

  // Normalisation de la matrice
  for (auto Vect = trainingMatrix.begin () ; Vect != trainingMatrix.end () ; ++Vect)
    {
         Min = Vect->Min ();
         Max = Vect->Max ();
        if (abs (Max) >= abs (Min))
        {
            for (auto it = Vect->begin () ; it != Vect->end () ; ++it)
                (*it) = (*it) / Max;
        }
        if (abs (Max) < abs (Min))
        {
            for (auto it = Vect->begin () ; it != Vect->end () ; ++it)
                (*it) = (*it) / Min;
        }
    }*/

  for (unsigned int i = 0 ; i < Numb ; ++i)
     {
       /* --- on le transforme en input/target */
           target[0] = target_[i];
           for (unsigned int j = 0 ; j < ncol ; ++j)
               input[j] = trainingMatrix[j][i];

       /* --- on fait un apprentisage du reseau  avec cette ligne*/
           Simulate(input, output, target, false);
           Output[i] = output[0];
           count++;
     }

  /*for (auto it = Output.begin () ; it != Output.end () ; ++it)
      (*it) *= MinMax;*/
  dAvgTestError /= count;

  input.clear();
  output.clear();
  target.clear();

  return count;
}

int MultiLayerPerceptron::Evaluate()
{
  int count = 0;
  return count;
}

void MultiLayerPerceptron::Run(const CVDouble & target_, const CMatDouble & Matrix, const int& maxiter, CVDouble & Output)
{
  int    countTrain = 0;
  int    countLines = 0;
  bool   Stop = false;
  bool   firstIter = true;
  double dMinTestError = 0.0;
  double MinMax;

  CMatDouble trainingMatrix = Matrix;
  CVDouble cible = target_;

  Output.clear ();  
  // Normalisation de la cible
 /* double Min = cible.Min ();
  double Max = cible.Max ();
  if (abs (Max) >= abs (Min))
    {
      MinMax = abs (Max);
      for (auto it = cible.begin () ; it != cible.end () ; ++it)
          (*it) = (*it) / Max;
    }
  else if (abs (Max) < abs (Min))
    {
      MinMax = abs (Min);
      for (auto it = cible.begin () ; it != cible.end () ; ++it)
          (*it) = (*it) / Min;
    }

  // Normalisation de la matrice
  for (auto Vect = trainingMatrix.begin () ; Vect != trainingMatrix.end () ; ++Vect)
    {
         Min = Vect->Min ();
         Max = Vect->Max ();
        if (abs (Max) >= abs (Min))
        {
            for (auto it = Vect->begin () ; it != Vect->end () ; ++it)
                (*it) = (*it) / Max;
        }
        if (abs (Max) < abs (Min))
        {
            for (auto it = Vect->begin () ; it != Vect->end () ; ++it)
                (*it) = (*it) / Min;
        }
    }*/

  //trainingMatrix.Normalise();

  /* --- init du generateur de nombres aleatoires  */
  /* --- et generation des pondÈrations aleatoires */
  InitializeRandoms();
  RandomWeights();

  /* --- on lance l'apprentissage avec tests */
  do {

    countLines += Train(target_, trainingMatrix);
    //Test(trainingMatrix);
    countTrain++;

    if(firstIter)
      {
        dMinTestError = dAvgTestError;
        firstIter = false;
      }

   // printf( "%i \t TestError: %f", countTrain, dAvgTestError);

    if ( dAvgTestError < dMinTestError)
      {
    //printf(" -> saving weights\n");
    dMinTestError = dAvgTestError;
    SaveWeights();
      }
    else if (dAvgTestError > 1.2 * dMinTestError)
      {
    //printf(" -> stopping training and restoring weights\n");
    Stop = true;
    RestoreWeights();
      }

  } while ( (!Stop) && (countTrain<maxiter) );

  //Test(trainingMatrix, Output);

  CVDouble input;// (trainingMatrix.size () - 1);

  CVDouble Res;

  for (unsigned i = 0 ; i < trainingMatrix[0].size (); ++i){
      for (unsigned j = 0 ; j < trainingMatrix.size (); ++j)
            input.push_back (trainingMatrix [j][i]);
      Predict (input, Res);
      Output.push_back(Res[0]);
      input.clear();
  }

 /* for (auto it = Output.begin () ; it != Output.end () ; ++it)
      (*it) *= MinMax;*/

  //printf("bye\n");

}
