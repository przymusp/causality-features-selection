
#include "../inst/include/CRcppExport.h"

using namespace std;

CRcppExport::CRcppExport (Rcpp::DataFrame DF,
                          unsigned int  p,
                          unsigned int  h,
                          Rcpp::IntegerVector sizeOfLayers,
                          unsigned int  iterations
                          )
{ 
    vector<vector<double> > Mat = Rcpp::as < vector<vector<double> > > (DF);
    vector<int> sizeOfLayers_ = Rcpp::as <vector<int> > (sizeOfLayers);
    
    
    unsigned Nc = Mat.size ();
    
    M.resize (Nc);
    
    unsigned i = 0;
    
    // Conversion des données dataFrame en matrice en C++
    while(i < Nc)
    {
        for (auto Value = Mat[i].begin () ; Value != Mat[i].end () ; ++Value)
        {
            M[i].push_back (*Value);
        }
        i++;
    }

// Prediction
  CNeuralNVarModel O (M, p, h, sizeOfLayers_, iterations);
    
    Obj = O;
    
  Pred = Obj.getPredicted ();
    
  Indice_Confiance = Obj.getIndConfiance();
    
  /* On construit l'objet de sortie sous forme de dataFrame */
  int nc = Pred.size(); // nr = tempMat[0].size() ;
  Rcpp::List list( nc ) ;
  for ( int j = 0; j < nc; j++) 
    list[j] = Rcpp::wrap( Pred[j].begin(), Pred[j].end() ) ;
  Output = list ;
     /*Output = Rcpp::DataFrame::create (
                                     Rcpp::Named("Values") = Pred[0],
                                     Rcpp::Named("Coefficient of determination") = Indice_Confiance
     );*/
    }
/****************************************************/
Rcpp::NumericVector CRcppExport::simulate (Rcpp::DataFrame DF)

  {
    vector<vector<double> > Mat = Rcpp::as < vector<vector<double> > > (DF);
     
     int nc = Mat.size();
     
     Struct::CMatDouble P (nc);
 
     unsigned i = 0;
     
     // Conversion des données dataFrame en matrice en C++
     while(i < nc)
     {
         for (auto Value = Mat[i].begin () ; Value != Mat[i].end () ; ++Value)
         {
             P[i].push_back (*Value);
         }
         i++;
     }
 
      Struct::CVDouble SM = Obj.simulate (P);
      Rcpp::NumericVector list = Rcpp::wrap( SM );
 
      return list;
 
 }
/****************************************************/
void CRcppExport::train (Rcpp::DataFrame DF)

{
    vector<vector<double> > Mat = Rcpp::as < vector<vector<double> > > (DF);
    
    int nc = Mat.size();
    
    Struct::CMatDouble P (nc);
    
    unsigned i = 0;
    
    // Conversion des données dataFrame en matrice en C++
    while(i < nc)
    {
        for (auto Value = Mat[i].begin () ; Value != Mat[i].end () ; ++Value)
        {
            P[i].push_back (*Value);
        }
        i++;
    }
    
    Obj.train (P);

    
}
