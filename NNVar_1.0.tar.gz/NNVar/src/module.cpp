/*
*' VARNN (Vector Auto regressive Neural Network) Model
*/
                                                                                                     
#include <Rcpp.h>
#include "../inst/include/CRcppExport.h"
#include "../inst/include/Tests.h"
#include "../inst/include/CGrangerCausality.h"

                                                                                                     
using namespace Rcpp ;                                                                                                     

RCPP_MODULE (neuralNet) {

/*' Classe RCppExport specify the prediction module.
 *' Two functions are available, predict() wich returns the predictions of the target attribut
 *' and temporalMatrix wich returns the temporal p decomposition of the time series
 */
  class_<CRcppExport> ("VARNN")
  .constructor <Rcpp::DataFrame,
                unsigned int,
                unsigned int,
                Rcpp::IntegerVector,
                unsigned int> ()
  .method ("predict", &CRcppExport::getOutput, "Provides the predictions of the initial data")
  .method ("forecast", &CRcppExport::simulate, "Provides the predictions of the input data")
  .method ("learn", &CRcppExport::train, "Use the NN for a learning from data")
  ;
    class_<DickeyFuller> ("DickeyFuller")
    .constructor <Rcpp::NumericVector, int> ()
    .method ("summary", &DickeyFuller::summary, "Summary of the test")
    .method ("lag", &DickeyFuller::getLag, "return the value of the la parameter")
    .method ("df", &DickeyFuller::getDF, "return the value of test")
    ;
    class_<CausalityTest> ("CausalityTest")
    .constructor <Rcpp::NumericVector, Rcpp::NumericVector, int, bool> ()
    .method ("summary", &CausalityTest::summary, "Summary of the test")
    .method ("pvalue", &CausalityTest::get_p_value, "return the p-value of the test")
    .method ("Ftest", &CausalityTest::get_F_test, "return the value of F test")
    ;
    
}
