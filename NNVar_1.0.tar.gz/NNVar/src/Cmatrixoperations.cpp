
#include <cstdlib>

#include "../inst/include/Cmatrixoperations.h"

using namespace nsUtil;
using namespace std;
using namespace Struct;

namespace MatrixOperations
{


/* Evaluation de la  Regression bidimensionelle : On calcule le coéfficient  de  determination
 * R^2 entre deux colonnes  X1 et  X2  afin  de detecter si il y a une colinéarité entre eux */

double Reg (const CVDouble & X1, const CVDouble & X2)
{
    CMatDouble X , B, A;
    CVDouble beta, teta;
    CVDouble predicted;
    CVDouble Y = X2;
    double R = 0.0;
    X.push_back(X1);

    MultCVDouble (Trans (X), X, B);
    Y.Standardise ();
    //X.Standardise();
    if (abs (Det (X)) > 0.000001)
    {
         Inverse (B, A);
         //teta = Trans (X) * Y;
         MultCVDouble (Trans (X), Y, teta);
         //beta = A * teta;
         MultCVDouble (A, teta, beta);
         //predicted = X * beta;
         MultCVDouble (X, beta, predicted);
         predicted.Standardise();
         //Y.Standardise ();
         if (Y.StdDev () == 0 && predicted.StdDev() == 0) return 0;
         if (Y.StdDev () == 0 && predicted.StdDev() != 0) return 1;
         R = pow (predicted.StdDev ()  /  Y.StdDev () , 2);
         return R;
     }
    else return 1;
}

/***********************************************************************************/

double Reg (const CMatDouble & X1, const CVDouble & X2)
{
    CMatDouble X = X1 , B, A;
    CVDouble beta, teta;
    CVDouble predicted;
    CVDouble Y = X2;
    double KEx = 1E-5;

    //B = Trans (X) * X;
    MultCVDouble (Trans (X), X, B);
    Y.Standardise ();
    //X.Standardise();

    if (abs (Det (B)) > KEx)
    {
         Inverse (B , A);
         //teta = Trans (X) * Y;
         MultCVDouble (Trans (X), Y, teta);
         //beta = A * teta;
         MultCVDouble (A, teta, beta);
         //predicted = X * beta;
         MultCVDouble (X, beta, predicted);

         A.clear();
         B.clear();
         teta.clear();
         beta.clear();

         if (Y.StdDev () < KEx && predicted.StdDev() < KEx) return 1;
         if (Y.StdDev () < KEx && predicted.StdDev() >= KEx) return 0;

         return pow (predicted.StdDev ()  /  Y.StdDev () , 2);
     }

    else return 1;
}

/***********************************************************************************/

/* Régression par la méthode des moindres carrés : résolution matricielle */

void regression (const CMatDouble & Mn, const CVDouble & Y,  CVDouble & pBeta ) throw (CException)
{

    unsigned int i= 0;
    CMatDouble A, B, M = Mn;
    CVDouble  Beta, Teta;
    CVDouble black_list ;
    pBeta.clear ();
    pBeta.resize (M.size ());

/** Elimination de la deuxième colonne de chaque couple ayant un determinant nul **/

    MultCVDouble (Trans (M), M, B);

    //if (abs(Det (B)) < 1E-10)
        //throw CException ("Singular Regression Matrix", KSingularMatrix);
    Inverse (B , A);
    //Beta = Trans (M) * Y ;
    MultCVDouble (Trans (M), Y, Teta);

    //Beta = A * Beta;
    MultCVDouble (A, Teta, Beta);
    //cout << Beta << endl;

    Teta.clear ();
    A.clear();
    M.clear();
    B.clear();

    // Beta globale

    if (black_list.size () != 0)
     {
       for (i = 0 ; i < black_list.size () ; ++i)
        {
           pBeta[black_list[i]] = Beta[i];
        }
     }
    else
        pBeta = Beta;
    Beta.clear();
}
/***********************************************************************************/
void Regression (const CMatDouble & Mn, const CVDouble & Y,  CVDouble & pBeta ) throw (CException)
{

    unsigned int i= 0;
    CMatDouble A, B, M = Mn;
    CVDouble  Beta, Teta;
    CVDouble black_list ;
    pBeta.clear ();
    pBeta.resize (M.size ());

/** Elimination de la deuxième colonne de chaque couple ayant un determinant nul **/
    // M.Standardise ();

    for (i = 0 ; i < M.size () ; ++i)
        pBeta [i] = (0);

    // Reduce M
    Reduce (M, black_list);

    //B = Trans (M) * M;
    MultCVDouble (Trans (M), M, B);

    B.Normalise();

    if (abs(Det (B)) < 1E-10)
        throw CException ("Singular Regression Matrix", KSingularMatrix);
    Inverse (B , A);
    //Beta = Trans (M) * Y ;
    MultCVDouble (Trans (M), Y, Teta);

    //Beta = A * Beta;
    MultCVDouble (A, Teta, Beta);
    //cout << Beta << endl;

    Teta.clear ();
    A.clear();
    M.clear();
    B.clear();

    // Beta globale

    if (black_list.size () > 0)
     {
       for (i = 0 ; i < black_list.size () ; ++i)
        {
           pBeta[black_list[i]] = Beta[i];
        }
     }
    else
        pBeta = Beta;
    Beta.clear();
    //cout << "pBeta: " << pBeta.size() << endl;
    //cout << "Beta: " << Beta << endl;
    /*cout << "Beta: " << Beta.size() << endl;*/
    //cout << "list: "<< black_list.size() << endl;
}
/* Elimination des redondances par regression multiple avec
 * un coéfficient  de  determination   superieur   à  0.9  */
void Reduce (CMatDouble & M, double alpha, CVDouble & list)
{
    unsigned int j, i, x, w ;
    CMatDouble  P;
    list.clear ();
    //const double KEps = 1E-5;

   list.reserve (M.size ());
   for (i = 0 ; i < M.size () ; ++i)
       list.push_back (i);

   /*    * /  for (i = 1 ; i < M.size () ; ++i)
       if ( abs (M[i].Mean ()) < KEps  && M[i].StdDev () < KEps)
       {
           M.erase (M.begin () + i);
           list.erase (list.begin () + i);
       } /*    */

    for (x = 1 ; x < M.size () ; ++x) {
       P.reserve (x);
       for (w = 0 ; w < x ; ++w)
           P.push_back (M[w]);

       for (j = x ; j < M.size () ; ++j) {
           if (Reg (P , M[j]) > alpha) {
                M.erase (M.begin () + j);
                list.erase (list.begin () + j);
            }
        }  // end j
       P.clear ();
     }  // end x
}

/***********************************************************************************/

void Reduce (CMatDouble & M, CVDouble & list)
{
    unsigned int x ;
    CMatDouble  P, Dt;
    list.clear ();
    const double KEps = 1E-10;

    //M.Standardise();
    list.reserve (1);
    P.reserve (1);

   P.push_back (M[0]);
   list.push_back (0);
    for (x = 1 ; x < M.size () ; ++x)
    {
        list.reserve (1);
        P.reserve (1);
       if ( M[x].StdDev () > 1E-10)
       {
        P.push_back (M[x]);
        MultCVDouble (Trans (P) , P, Dt);
        //cout <<"av: " << Det (Dt) << endl;
        Dt.Normalise ();
        //cout << "ap: " << Det (Dt) << endl;
        if ( abs (Det (Dt))  < KEps)
         {
             P.pop_back();
         }
        else
            list.push_back (x);
     } // end j
    } // end x
    M.clear();
    M = P;
}

/***********************************************************************************/

/// Building the multidimensional matrix of the Var(p) Model

void P_Part (CVDouble & V , CMatDouble & Present, CMatDouble & M, unsigned int & p)
{
 unsigned int  N = V.size ();
 unsigned int i;
 unsigned int j;
 CVDouble P;
 P.reserve(N - p);
for (i = p ; i < N ; i++)
    {
      P.push_back (V[i]) ;
    }
 Present.push_back(P);
 P.clear ();

 for (j = 1 ; j <= p ; j++)
  {
    for (i = p ; i < N ; i++)
      {
         P.push_back (V[i - j]) ;
       }
     M.push_back (P);
     P.clear ();
    }
      //M = Trans(M);
  }

/*********************************************************************************/

/// Building the multidimensional matrix of the Var(p) Model

void Pr_Part (CVDouble & V, CMatDouble & M, unsigned int & p)
{
 unsigned int  N = V.size ();
 unsigned int i;
 unsigned int j;
 CVDouble P ;

 for (j = 1 ; j <= p ; j++)
    {
    for (i = p + 1 ; i <= N ; i++)
      {
         P.push_back (V[i - j]) ;

       }
    M.push_back (P);
    P.clear ();
    }
}

/***********************************************************************************/

void Diff (CVDouble & V) {
       for (auto it = V.end () -1 ; it != V.begin () ; --it)
               *it -= *(it-1) ;
       V.erase (V.begin ());
}
} // namespace matrixoperations
