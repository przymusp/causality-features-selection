#include "../inst/include/Struct.h"

using namespace nsUtil;
using namespace std;

namespace Struct
{
/***********************************************************************************/
double CVDouble::Mean () const throw (CException)
  {
    if (this->size () == 0)
         throw CException ("Vector of size null", KVectNullSize);
    double Sum = 0;
    for (auto it = this->begin() ; it!= this->end() ; ++it)
        Sum += (*it);
    return Sum / this->size();
  };
/***********************************************************************************/
bool CVDouble::Contains (unsigned & x)
{
    if (this->size () == 0) return false;
    bool test = false;
    for (auto Val = this->begin() ; Val != this->end() ; ++Val)
        if (*Val == x)
        {
            test = true;
            break;
        }
    return test;
}
/***********************************************************************************/
double CVDouble::CMean () const throw (CException)
{
    if (this->size () == 0)
         throw CException ("Vector of size null", KVectNullSize);

    double m = 0.0;
    int c = 0;
    for (auto it = this->begin() ; it!= this->end() ; ++it)
    {
        if ( ! std::isnan (*it) )
        {
            m += (*it);
            ++c;
        }
    }
    return m / c;
}

/***********************************************************************************/

double CVDouble::StdDev () const throw (CException)
{
    if (0 == this->size ())
               throw CException ("Vector of size null", KVectNullSize);
    double Sum = 0.0, Mean = this->Mean();
    for( auto it = this->begin() ; it != this->end() ; ++it)
    {
        Sum += pow (*it - Mean, 2);
    }
    return sqrt(Sum / (this->size ()));
};

/***********************************************************************************/

double CVDouble::Min () const throw (CException)
{
    if (0 == this->size ())
               throw CException ("Vector of size null", KVectNullSize);
    double min = *(this->begin());
     for (auto Val = this->begin() ; Val != this->end() ; ++Val)
         if ( *Val < min)
             min = *Val;
     return min;
};

/***********************************************************************************/

double CVDouble::Max () const throw (CException)
{
    if (0 == this->size ())
               throw CException ("Vector of size null", KVectNullSize);
    double max = *(this->begin());
     for (auto Val = this->begin() ; Val != this->end() ; ++Val)
         if (*Val > max)
             max = *Val;
     return max;
};

/***********************************************************************************/

void   CVDouble::Standardise () throw (CException)
{
    if (0 == this->size ())
               throw CException ("Vector of size null", KVectNullSize);
    double Mean = this->Mean (), sigma = this->StdDev();
    if (Mean != 0 && sigma > 1E-9)
      for (auto it = this->begin () ; it != this->end () ; ++it)
         (*it) = ((*it) - Mean);

};

/***********************************************************************************/
void   CVDouble::Normalise () throw (CException)
{
    if (0 == this->size ())
               throw CException ("Vector of size null", KVectNullSize);
    double Min = this->Min ();
    double Max = this->Max ();
    if (abs (Max) > abs (Min))
      for (auto it = this->begin () ; it != this->end () ; ++it)
            (*it) = (*it) / Max;
    if (abs (Max) < abs (Min))
      for (auto it = this->begin () ; it != this->end () ; ++it)
            (*it) = (*it) / Min;


};

/***********************************************************************************/

void CVDouble::Add  (double & m)  throw (CException)
{
        for (auto it = this->begin () ; it != this->end () ; ++it)
            (*it) += m;
}

/***********************************************************************************/

/* Nombre de points virgules dans un objet string */
unsigned int NbreDeCol (std::string ligne)
{
  unsigned int max = 1;
  for (const auto & val : ligne)
      if (val == ';')
          ++max ;
  return (max);
}

/***********************************************************************************/

/* Lecture du fichier csv et enregistrement les données dans un tableau 2 dimensions */
void lire_csv (const string & FileName , vector<vector<double>> & T) throw (CException)
{
unsigned int Nbln = 0, Nbrcol;
unsigned int i,j = 0, h = 0;
vector<string> ligne;
string lign,p,s;
ifstream ifs(FileName);

if ( !ifs )
        throw CException ("Impossible d'ouvrir le fichier", KCsvFileError);

for (getline(ifs, lign); ifs; getline(ifs, lign))
    {
        if(Nbln > 0)
            ligne.push_back (lign);
        //cout << lign << endl;
        Nbln++;
    }
 Nbln -= 1;

Nbrcol = NbreDeCol(ligne[0]);
T.reserve (Nbln);
for( i = 0 ; i < Nbln ; i++)
   {
    if (NbreDeCol(ligne[i]) != Nbrcol)
          throw CException ("Error in csv file structure", KCsvFileError);
    //cout << ligne[i][ligne[i].size () - 2] << endl;
    s = "", p = "";
    h = 0;
    T.push_back (vector<double> (Nbrcol) );

    /*for ( auto & val : ligne[i])
    {
       if (val != ';' && j < ligne[i].size () - 1)
          {
              s += val;
              p = s;
          }
       if (val == ';' || j == ligne[i].size () - 1)
           {
               if (s != "")
                 T[i][h] = stod (s);
               if (s == "")
                 T[i][h] = (double) NAN ;
               s = "";
               h++;
           }
       j++;
      }
   }*/


        for (j = 0 ; j < ligne[i].size ()  ; ++j)
         {
            //cout << ligne[i][ligne[i].size () - 2] << endl;
            //s = "";
            if(ligne[i][j] != '\n')
            {
            if (ligne[i][j] != ';')
               {
                   s += ligne[i][j];
                   p = s;
               }
            else
              {
               if (s != "")
                   T[i][h] = std::stod (s);
               else
                   T[i][h] = (double) NAN ;
                s = "";
                h++;
               }


            if ( s == "")
               T[i][h] = (double) NAN ;
            else
                T[i][h] = std::stod(p);
            }
        }
     }
};

//void lire_csv (const string & FileName,  vector<vector<double>>& Mat)
//{
//    ifstream ifs(FileName);
//    if (!ifs.is_open()) return;

//    vector <double> VLine;
//    string StrTmp, lign;
//    double DTmp;
//    //la ligne de headers
//    getline(ifs, lign);
//    unsigned NbComa (0);
//    size_t Pos (0);
//    for (Pos = lign.find ( ";", Pos) ; Pos != string::npos ; Pos = lign.find ( ";", Pos))
//    {
//        ++Pos;
//        ++NbComa;
//    }

//    //cout << NbComa << endl;


//    //for (getline(ifs, lign); ifs; getline(ifs, lign))
//    //{
//getline(ifs, lign);
//        size_t Ind1, Ind2;
//        Ind1 = lign.find ( ";");
//        cout << Ind1 << endl;

//        for (unsigned i (1); i < NbComa - 2 ; ++i)
//        {
//            Ind2 = lign.find ( ";", Ind1 + 1);
//            Ind1 = lign.find ( ";", Ind2 + 1);

//            cout << Ind2 << ' '<<  Ind1 << flush << endl;
//             cout << lign.substr(Ind2, Ind1) << flush << endl;
//        }

        /*istringstream iss (lign);
        cout << lign << endl;
        getline (iss, StrTmp, ';');
        for (getline (iss, StrTmp, ';');iss; getline (iss, StrTmp, ';'))
        {

            if (0 == StrTmp.size ()) DTmp = MAXDOUBLE;
            else {
                DTmp = stod (StrTmp);
            }
            VLine.push_back(DTmp);
            cout << setw (10) << DTmp << flush;
        }
        cout << endl;
        Mat.push_back(VLine);*/
   // }
//}
/* Construire la matrice transposée X organisée par colonnes
 *  à partir d'une matrice  organisée  par lignes */


/***********************************************************************************/

void CMatDouble::Init_Mat( const vector< vector <double> > & M)
    {
        unsigned int i,j;
        this->clear ();
        unsigned int Nblign = M.size ();
        unsigned int NbColumn = M[0].size () - 1;

        this->resize (NbColumn);
        for( j = 0 ; j < NbColumn ; ++j)
          {
            (*this) [j] = CVDouble (Nblign);
            for( i = 0 ; i < Nblign  ; ++i)
                (*this) [j][i] = M[i][j+1];
          }
    };

/***********************************************************************************/

// Verification si un vecteur contient une valeur nan
bool CVDouble::NBR_NAN() const
{
    bool test = 1;
    for (const auto & val : (*this) )
        if (std::isnan (val) )
        {
            test = 0;
            break;
        }
     return test;
}

/***********************************************************************************/

// Interpolation linéaire
void CMatDouble::Interpol () throw (CException)
   {
       if (this->size () == 0)
           throw CException ("Vector of size null", KVectNullSize);
       double moy ;
       CVDouble T ;
       for (auto it = this->begin () ; it!= this->end () ; ++it)
       {
           if(it->NBR_NAN() == 0)
           {
               moy = it->CMean ();

               if (std::isnan(*(it->begin ())))
                   *(it->begin ()) = moy;

               for (auto val = it->begin () + 1 ; val!= it->end () ; ++val)
                   if (std::isnan(*val))
                       *val = *(val - 1);
              /* for (auto val = it->begin () ; val!= it->end () ; ++val)
               {
                   if (! std::isnan(*val)) /// Si la première valeure est null, on l'affecte la moyenne du vecteur
                       T.push_back(*val);
                   if (std::isnan(*val) && T.size  () == 0)
                       *val = moy;
                   if (std::isnan(*val) && T.size  () != 0)
                       *val = T.Mean ();*/
               }
           }
       }
/***********************************************************************************/

void CMatDouble::Standardise ()
{
    for( auto it = this->begin() ; it!= this->end() ; ++it)
        it->Standardise ();
}

/***********************************************************************************/
void CMatDouble::Normalise ()
{
    for( auto it = this->begin() ; it!= this->end() ; ++it)
        it->Normalise ();
}

/***********************************************************************************/

CMatDouble Trans (const CMatDouble & M)
{
    unsigned int n = M.size(), m = M[0].size ();
    CMatDouble T (m);
    for (unsigned int i = 0 ; i < m ; ++i)
    {
        T[i] = CVDouble (n);
         for (unsigned int j = 0 ; j < n ; ++j)
             T[i][j] = M[j][i];
    }
        return T;
}

/***********************************************************************************/

void permute( CVDouble &X , CVDouble &Y)
{
    double a;
    for ( unsigned int k = 0 ; k < X.size() ; ++k)
    {
        a = X[k];
        X[k] = Y[k];
        Y[k] = a;
    }

};

/***********************************************************************************/

bool Trig (CMatDouble & A ,  CMatDouble & B)
{
    double pivot = 1, coef=0, max ;
    unsigned int i,j,k,l, indice_max;
    unsigned int n = A.size();
    vector<double> T, P;

// Pivot de Gauss
    // Reorganisation de la matrice
    for ( k = 0 ; k < n-1 ; ++k)
    {
        T.resize(0);
        P.resize(0);
        indice_max = k, max = A[k][k];
        for( l = k+1 ; l < n ; l++)
        {
            if (abs(A[l][k]) > abs(max) )
            {
                max = A[l][k];
                indice_max = l;
            }
        }
        if(indice_max > k)
            {
            permute(B[k] , B[indice_max]);
            permute(A[k] , A[indice_max]);
            }
     // Affectation du pivot
      pivot = A[k][k];
        try
    {
        if( pivot == 0 )
          {
          throw string("ERREUR : Matrice non reversible!");
          }
    }
        catch(string const& chaine)
        {
            cout<<chaine<<endl;
            return 0;
        }
// Triangularisation de la matrice A
        for ( i = k+1 ; i < n ; ++i)
           {
             coef = A[i][k];
              for ( j = 0 ; j < n ; ++j)
                 {
                  A[i][j] -= (coef * A[k][j] / pivot);
                  B[i][j] -= (B[k][j] * coef / pivot);
                  }
           }

        } // Matrice Triangulaire
    try
        {
            if( A[n-1][n-1] == 0 )
              {
              throw string("ERREUR : Matrice non révérsible!");
              }
        }
            catch(string const& chaine)
            {
                cout<<chaine<<endl;
                return 0;
            }
    B = Trans(B);
    return 1;
}

/***********************************************************************************/

double Det ( const CMatDouble & M)
{
    CMatDouble A = M;
    double pivot = 1, coef = 0, max, det = 1 ;
    unsigned int i, j, k, l, indice_max;
    unsigned int n = A.size ();

// Pivot de Gauss
    for (k = 0 ; k < n-1 ; ++k)
    {
        indice_max = k, max = A[k][k];
        for (l = k+1 ; l < n ; l++)
        {
            if (abs (A[l][k]) > abs (max) )
            {
                max = A[l][k];
                indice_max = l;
            }
        }
        if(indice_max > k)
            {
            permute(A[k] , A[indice_max]);
            }
        pivot = A[k][k];
        if (pivot == 0)
            return 0.0;
        det *= pivot;

// Triangularisation de la matrice A
        for ( i = k+1 ; i < n ; ++i)
           {
             coef = A[i][k];
              for ( j = 0 ; j < n ; ++j)
                  A[i][j] -= (coef * A[k][j] / pivot);
           }
        } // Matrice Triangulaire
    det *= A[n-1][n-1];
    return det;
}

/***********************************************************************************/

// Resolution du système linéaire A*X = B
void Resolve(const CMatDouble  & A , const CVDouble  & B, CVDouble & X)
{
    double somme = 0;
    int ind = 0, j;
    unsigned int n = B.size();
    X.clear ();
    X.resize (n);
// Resolution du système linéaire
    X[n - 1] = B[n-1]/A[n - 1][n - 1];
    for (ind = n-2 ; ind >= 0 ; ind--)
    {
        somme = B[ind];
        for (j = ind + 1 ; j < (int) n ; ++j)
            somme -= A[ind][j] * X[j];
        X[ind]  =  somme / A[ind][ind];
    }
}

/***********************************************************************************/

// Matrice Inverse
void Inverse ( const CMatDouble & B, CMatDouble & M) throw (CException)
{
    bool a;
    unsigned int i , j , n = B.size();
    CMatDouble I(n), A = B;

    M.clear ();
    M.resize (n);

    for (i = 0 ; i < n ; ++i)
        {
            M[i] = CVDouble (n);
            I[i] = CVDouble (n);
            for (j = 0 ; j < n ; ++j)
            {
                if ( i == j) I[i][j] = 1;
                else I[i][j] = 0;
            }
        }
        a = Trig(A,I);
        if( a == 1)
         {
            for (i = 0 ; i < n ; ++i)
            {
                Resolve(A , I[i], M[i]);
             }
         }
    else
    {
         throw CException ("Singular Matrix", KSingularMatrix);
    }
        I.clear ();
}

/*****************  Save results  ****************************************/

void Save_Predictions (CVDouble & M ,CVChar & Interpol, CVDouble & Ind_Conf, ofstream & file)
{
    unsigned int N = M.size  ();

    for (unsigned int i = 0 ; i < N ; i++)
     {
              file << M[i] << ";" << Interpol[i] << ";" << Ind_Conf[i] << fixed << endl;
     }
}
/***********************************************************************************/



double stod(const string &strInput)
{
    /* STOD: String to double  */
    /* Written by Mathias Van Malderen */
    double dbl_one = 0;
    double dbl_two = 0;
    double dbl_final = 0;
    int strlen;
    bool dec_pt = false;
    int nums_before_dec = 0;
    int nums_after_dec = 0;
    strlen = strInput.length();
    /* Check whether the string can be transformed into a number */
    if(strInput[0] == '0' && strInput[1] == '0')
    {
        // invalid number !
        return 0;
    }
    for(int i = 0; i < strlen; i++)
    {
        if(strInput[i] == '0' || strInput[i] == '1' || strInput[i] == '2' || strInput[i] == '3' || strInput[i] == '4' || strInput[i] == '5' || strInput[i] == '6' || strInput[i] == '7' || strInput[i] == '8' || strInput[i] == '9')
        {
            // valid number
        } else if(strInput[i] == '.'){
            if(dec_pt)
            {
                // there was already a decimal point counted
                // invalid number !
                return 0;
            } else {
                dec_pt = true; // increment by one
            }
        } else {
            // invalid number !
            return 0;
        }
    }
    /* Convert the number */
    // STEP 1: Calculate the amount of numbers before/after the decimal point (if there's one)
    if(dec_pt) // if there's a decimal point in the number
    {
        for(int i = 0; i < strlen; i++)
        {
            if(strInput[i+1] != '.')
            {
                nums_before_dec++;
            } else {
                nums_before_dec++;
                break;
            }
        }
        nums_after_dec = strlen-nums_before_dec;
        nums_after_dec -= 1;
    } else {
        // This piece of code was added later as a BUGFIX !
        // Now the STOD-function is working 100% perfect !!!
        nums_after_dec = 0;
        nums_before_dec = strlen;
    }

    // STEP 2: Convert the string to a real number
    for(int i = 0; i < nums_before_dec; i++)
    {
        switch(strInput[i])
        {
            case '0':
                dbl_one += 0 * apow(10, (nums_before_dec - i));
                break;
            case '1':
                dbl_one += 1 * apow(10, (nums_before_dec - i));
                break;
            case '2':
                dbl_one += 2 * apow(10, (nums_before_dec - i));
                break;
            case '3':
                dbl_one += 3 * apow(10, (nums_before_dec - i));
                break;
            case '4':
                dbl_one += 4 * apow(10, (nums_before_dec - i));
                break;
            case '5':
                dbl_one += 5 * apow(10, (nums_before_dec - i));
                break;
            case '6':
                dbl_one += 6 * apow(10, (nums_before_dec - i));
                break;
            case '7':
                dbl_one += 7 * apow(10, (nums_before_dec - i));
                break;
            case '8':
                dbl_one += 8 * apow(10, (nums_before_dec - i));
                break;
            case '9':
                dbl_one += 9 * apow(10, (nums_before_dec - i));
                break;
            default:
                // invalid number !
                return 0;
        }
    }
    dbl_one = dbl_one / 10; // little fix
    for(int i = 0; i < nums_after_dec; i++)
    {
        switch(strInput[i + nums_before_dec + 1])
        {
            case '0':
                dbl_two += (0 / apow(10, i+1));
                break;
            case '1':
                dbl_two += (1 / apow(10, i+1));
                break;
            case '2':
                dbl_two += (2 / apow(10, i+1));
                break;
            case '3':
                dbl_two += (3 / apow(10, i+1));
                break;
            case '4':
                dbl_two += (4 / apow(10, i+1));
                break;
            case '5':
                dbl_two += (5 / apow(10, i+1));
                break;
            case '6':
                dbl_two += (6 / apow(10, i+1));
                break;
            case '7':
                dbl_two += (7 / apow(10, i+1));
                break;
            case '8':
                dbl_two += (8 / apow(10, i+1));
                break;
            case '9':
                dbl_two += (9 / apow(10, i+1));
                break;
            default:
                // invalid number !
                return 0;
        }
    }
    // STEP 3: Return the converted string as a double:
    dbl_final = dbl_one + dbl_two;
    return dbl_final;
}
/* This function 'apow' raises x to the power of y, it's a dependency of 'stod' */
double apow(const float &x, int y)
{
    double result = 1;
    if(y == 0)
        return result;
    if(y < 0)
    {
        y = -y;
        for(int i = 0; i < y; i++)
            result = result * x;
        return 1/result;
    }
    for(int i = 0; i < y; i++)
        result = result * x;
    return result;
}


// Fonction de repartition empirique
double F (const CVDouble &T,const double &x, const int &n)
{
    double F = 0;

    for (int i = 0; i < n; ++i)
        if (T[i] <= x)
            F = F + 1.0;
     return F / n;
}

// 1er quartile
double Quartil_1 (const CVDouble &T)
{
    CVDouble Tab;
    double Q1;

    for (double a:T)
        if (!std::isnan (a))
        {
            Tab.reserve (1);
            Tab.push_back(a);
        }
    for (double val:Tab)
        if (F(Tab, val, T.size ()) >= 0.25)
        {
            Q1 = val;
            break;
        }
    Tab.clear ();
    return Q1;
}

// 3eme quartile
double Quartil_3 (const CVDouble &T)
{
    CVDouble Tab;
    double Q3;

    for (double a:T)
        if (!std::isnan (a))
        {
            //Tab.reserve (1);
            Tab.push_back (a);
        }
    for (double val:Tab)
        if (F (Tab, val, T.size ()) >= 0.75)
        {
            Q3 = val;
            break;
        }
    Tab.clear ();
    return Q3;
}

/* detects outliers in a numeric column and updates them with a NULL value */

void boxPlotOutliersDetection (CMatDouble & M,
                                 unsigned fstd)
{
    double Q1, Q3, LU, LF;
    for (auto cVec = M.begin () ; cVec != M.end () ; ++cVec)
     {       
        Q1 =  Quartil_1 (*cVec);
        Q3 =  Quartil_3 (*cVec);

        LU = Q1 - (fstd * (Q3 - Q1));
        LF = Q3 + (fstd * (Q3 - Q1));

        for (auto cVal = cVec->begin () ; cVal != cVec->end () ; ++cVal)
           {
            if (!std::isnan (*cVal))
                if ( (*cVal) < LU || (*cVal) > LF)
                {
                    (*cVal) = NAN;
                }
            }
       }
};

void algebraicOutlier (CMatDouble & M, unsigned fstd)
{

    double avg, stdev;
for (auto cVec = M.begin () ; cVec != M.end () ; ++cVec)
    {
    avg = cVec->Mean ();
    stdev = cVec->StdDev ();
    for (auto cVal = cVec->begin () ; cVal != cVec->end () ; ++cVal)
       {
        if (!std::isnan (*cVal))
            if ( abs ((*cVal - avg) / stdev) >= (double) fstd)
                    (*cVal) =  NAN;
            }
     }
}

} // namespace Struct
