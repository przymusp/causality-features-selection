#include "../inst/include/Operateurs.h"
using namespace std;
using namespace Struct;

ostream& operator << (ostream & os, const vector<int> &A)
{
  os << "[1:]";
    for( unsigned j = 0 ; j < A.size(); ++j)
        os << setprecision (6) << fixed << ' ' << A[j];
    os << endl;
return os;
}

ostream& operator << (ostream & os, const CVDouble &A)
{
    unsigned int j ;
  os << "[1:]";
    for( j = 0 ; j < A.size(); ++j)
        os << setprecision (6) << fixed <<" "<< A[j];
    os << endl;
return os;
}

ostream& operator << (ostream & os, const CMatDouble &A)
{
    int Nblign = A.size();
    int NbColumn = A[0].size();

    os << setprecision(4)<<"    ";
    for( int j = 0 ; j < Nblign ; ++j)
        os<< setprecision(6) << "    " << fixed<<"[,"<<j+1<<"]  ";
    os<<"\n";
    for( int i = 0 ; i < NbColumn  ; ++i)
        {
            os << "[" << i+1  << ",]";
            for( int j = 0 ; j < Nblign ; ++j)
                os << setprecision(6) << "    " << fixed << A[j][i];
            os<<"\n";
        }
    return os;
}

ostream& operator << (ostream & os, const vector<vector<double>> &A)
{
    int Nblign = A.size();
    int NbColumn = A[0].size();

    for( int j = 0 ; j < Nblign ; ++j)
        os<<"[,"<<j+1<<"]  ";
    os<<"\n";
    for( int i = 0 ; i < NbColumn  ; ++i)
        {
            os << "[" << i+1  << ",]";
            for( int j = 0 ; j < Nblign ; ++j)
                os << setprecision(4) << "   " << fixed << A[j][i];
            os<<"\n";
        }
    return os;
}

/******** Produit vecteur--vecteur *********/
void MultCVDouble (const CVDouble & A, const CVDouble & B, CVDouble & Res)
{
    unsigned int i, n = A.size();
    Res.clear();
    Res.resize (n);

    for (i = 0 ; i < n ; ++i)
           Res[i]  = (A[i] * B[i]) ;
}

/********* Produit Matric--vecteur *********/
void MultCVDouble (const CMatDouble & A, const CVDouble & B, CVDouble & Res)
{
    unsigned int i , j, n = A[0].size (), m = B.size ();
    Res.clear();
    Res.resize(n);

    for (i = 0 ; i < n ; ++i)
    {
      for (j = 0 ; j < m ; ++j)
       {
           Res[i] += (A[j][i] * B[j]) ;
        }
    }
}

/*************** Produit Matrice--Matrice  ***************/
void MultCVDouble (const CMatDouble & A, const CMatDouble & B, CMatDouble & Res)
{
    unsigned int  n = B.size();
    Res.clear ();
    Res.resize (n);
    for (unsigned int i = 0 ; i < n ; ++i)
    {
        MultCVDouble (A, B[i], Res[i]);
    }
}

