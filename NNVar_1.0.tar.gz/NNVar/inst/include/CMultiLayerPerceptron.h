#ifndef CMULTILAYERPERCEPTRON_H
#define CMULTILAYERPERCEPTRON_H


#include"Struct.h"


struct Neuron {
  double  x;     /* sortie */
  double  e;     /* erreur */
  double* w;     /* poids  */
  double* dw;    /* dernier poids pour les momentum  */
  double* wsave; /* poids sauvegarde */
};

struct Layer {
  int     nNumNeurons;
  Neuron* pNeurons;
};

class MultiLayerPerceptron {

  protected:

  int    nNumLayers;
  Layer* pLayers;

  double dMSE;
  double dMAE;

  void RandomWeights();

  void SetInputSignal (Struct::CVDouble & input);
  void GetOutputSignal(Struct::CVDouble & output);

  void SaveWeights();
  void RestoreWeights();

  void PropagateSignal();
  void ComputeOutputError(Struct::CVDouble & target);
  void BackPropagateError();
  void AdjustWeights();

  void Simulate(Struct::CVDouble & input, Struct::CVDouble & output, Struct::CVDouble & target, bool training);

public:

  double dEta;
  double dAlpha;
  double dGain;
  double dAvgTestError;

  MultiLayerPerceptron(int nl,  const std::vector<int> &);
  MultiLayerPerceptron() {}
  ~MultiLayerPerceptron();

  int Train(const Struct::CVDouble & target_,const Struct::CMatDouble & trainingMatrix);
  int Test (const Struct::CVDouble & target_,const Struct::CMatDouble & Matrix, Struct::CVDouble & Output);
  int Evaluate();
  void Predict (Struct::CVDouble &, Struct::CVDouble &);

  void Run(const Struct::CVDouble &,const Struct::CMatDouble &, const int&, Struct::CVDouble &);

};
#endif // CMULTILAYERPERCEPTRON_H
