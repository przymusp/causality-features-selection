#ifndef OPERATEURS_H
#define OPERATEURS_H

#include <utility>

#include "Struct.h"



// Affichage d'un vecteur
std::ostream& operator << (std::ostream & os, const Struct::CVDouble & A);

std::ostream& operator << (std::ostream & os, const std::vector<int> & A);
// Affichege d'une matrice
std::ostream& operator << (std::ostream & os, const Struct::CMatDouble &A);

std::ostream& operator << (std::ostream & os, const std::vector<std::vector<double> > &A);

Struct::CVDouble operator * (const Struct::CVDouble & A, const Struct::CVDouble & B);

void MultCVDouble (const Struct::CVDouble & A, const Struct::CVDouble & B, Struct::CVDouble & Res);
void MultCVDouble (const Struct::CMatDouble & A, const Struct::CVDouble & B, Struct::CVDouble & Res);
void MultCVDouble (const Struct::CMatDouble & A, const Struct::CMatDouble & B, Struct::CMatDouble & Res);

// Produit Matrice vecteur
Struct::CVDouble operator * (const Struct::CMatDouble & A, const Struct::CVDouble & B);

// Produit Matricielle
Struct::CMatDouble operator * (const Struct::CMatDouble & A, const Struct::CMatDouble & B);


#endif // OPERATEURS_H
