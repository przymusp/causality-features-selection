#ifndef CMATRIXOPERATIONS_H
#define CMATRIXOPERATIONS_H

#include "Operateurs.h"

namespace MatrixOperations
{
    double Reg              (const Struct::CMatDouble & X1, const Struct::CVDouble & X2);

    double Reg              (const Struct::CVDouble & X1, const Struct::CVDouble & X2);

    void regression         (const Struct::CMatDouble & , const Struct::CVDouble & ,  Struct::CVDouble &  ) throw (nsUtil::CException);

    void Regression         (const Struct::CMatDouble & , const Struct::CVDouble & ,  Struct::CVDouble &  ) throw (nsUtil::CException);

    void Reduce             (Struct::CMatDouble &, Struct::CVDouble & list);

    void P_Part             (Struct::CVDouble & V , Struct::CMatDouble & Present, Struct::CMatDouble & M, unsigned int & p) ; // Partitionner une matrice en p historiques

    void Pr_Part            (Struct::CVDouble & V, Struct::CMatDouble & M, unsigned int & p) ;

    void Diff (Struct::CVDouble & V);


}

#endif // CMATRIXOPERATIONS_H
