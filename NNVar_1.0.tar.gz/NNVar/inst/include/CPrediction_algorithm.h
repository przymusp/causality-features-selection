/*!
 * @file CPrediction_algorithm.h
 *
 * @author youssef hmamouche
 *
 * @date 16/11/2015
 *
 * @brief abstract classe defining the structure of the prediction models used
*/

/* ****************************************************************************
 * Tybpe: abstract classe defining the structure of the predictions models used
 * Author: youssef hmamouche
 * Date: 16/11/2015
 * ****************************************************************************/

#ifndef CPREDICTION_ALGORITHM_H
#define CPREDICTION_ALGORITHM_H

#include "Cmatrixoperations.h"

//using namespace MatrixOperations;

class CPrediction_algorithm
{
protected:
    
    unsigned int p;
    unsigned int h;
    unsigned int Nb_Ln ;    // nombre de lignes
    unsigned int Nb_Cl ;    // nombre d'attributs
    Struct::CMatDouble Predict ;    // Données initiales + prédictions
    Struct::CMChar Interpolated ;   // les valeurs interpolées
    Struct::CVDouble Ind_Confiance; // Evaluation des prédictions
public:
    
    CPrediction_algorithm (const Struct::CMatDouble &,
                           unsigned int &,
                           unsigned int &)     throw (nsUtil::CException);
    
    CPrediction_algorithm (void) {}
    
    ~CPrediction_algorithm (void) {}
    
    Struct::CVDouble getIndConfiance (void) {return Ind_Confiance;}
    
};

#endif // CPREDICTION_ALGORITHM_H