#ifndef CNEURALNVARMODEL_H
#define CNEURALNVARMODEL_H

#include <cstdlib>
#include <memory>

#include "CPrediction_algorithm.h"
#include "CMultiLayerPerceptron.h"

class CNeuralNVarModel:public CPrediction_algorithm
{
private:
    std::vector<int> sizeOfLayers_;
    unsigned int numLayers_;
    unsigned int iterations_;
    Struct::CMatDouble forecasts;
    std::vector <std::shared_ptr <MultiLayerPerceptron>> mpl;
public:
    CNeuralNVarModel (const Struct::CMatDouble &,
                      unsigned int    &,
                      unsigned int    &,
                      const std::vector<int> &,
                      unsigned int iterations);
    
    CNeuralNVarModel (){};
    
    ~CNeuralNVarModel(){}
    
    void NNVar ();
    
    Struct::CVDouble simulate (const Struct::CMatDouble & M);
    
    void train (const Struct::CMatDouble & M);
    
    Struct::CMatDouble getPredicted ()
    {
        return forecasts;
    }
};
#endif // CNEURALNVARMODEL_H
