#ifndef CGRANGERCAUSALITY_H
#define CGRANGERCAUSALITY_H

#include <Rcpp.h>
#include <cstdlib>
#include <memory>

#include "Struct.h"

/******************************************************/

Struct::CVDouble VECbivar (Struct::CMatDouble, unsigned, bool d  = false );


/*****************  causality test  *********************/

class CausalityTest {
private:
    
    Struct::CVDouble ts1;
    Struct::CVDouble ts2;
    double Ftest;
    unsigned lag;
    double p_value;
    double criticTest;
    
public:
    
    CausalityTest (Rcpp::NumericVector ts1_,
                   Rcpp::NumericVector ts2_, int lag_, bool d = false) throw (nsUtil::CException);
    CausalityTest (){};
    ~CausalityTest (){};
    
    double get_p_value ();
    double get_F_test () ;
    void summary ();
    };
#endif
