\name{Learn}
\alias{Learn}
\docType{package}
\title{
The learning function
}
\description{
This function modify the coefficients of the model based on the the new learning data in the input. The learning algorithm is based on the retropropagation algorithm.
}
\usage{
learn(F)	
}
\arguments{
\item{F}{F dataframe multivariate time series, on which the neural network learns}
}
\examples{
\dontrun{
Learn()
}
}
