\name{vnnet}
\alias{vnnet}
\docType{package}
\title{
Building the model
}

\description{
The vnnet function build the model. The model is based on the multilayer percetron structure. It uses the p previous values of of all the series to predict the futur values of the series.
}
\usage{
vnnet(series, p, h, hiddenLayers, iters )
}
\arguments{
\item{series}{series Numerical time series  dataframe}

\item{p}{the lag parametre of the model.}

\item{h}{the number of the predictions.}

\item{hiddenLayers}{A numerical vector describing the size of the hidden layers to use.}

\item{iters}{the number of the iterations.}
}
\examples{
\dontrun{
rcpp_hello_world()
}
}
