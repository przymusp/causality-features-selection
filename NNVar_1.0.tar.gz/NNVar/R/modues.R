

require(Rcpp)

loadModule('neuralNet', TRUE)

Pred =  Module ('neuralNet', PACKAGE = "NNVar") ;


vnnet <- function(series, p, h, sizeOfLayers, iterations){
    varp = Pred $ VARNN ;
    v = new (varp, series, p, h, sizeOfLayers, iterations) ;
    return (v) ;
}

#' Augmented Dickey_Fuller test
#'
#' @param tS Numerical series
#' @param p The lag parameter
#' @details
#' @return summary () :  shows the test results
#'         df () : returns the value of the test

df.test <- function(tS, p){
    test = Pred $ DickeyFuller ;
    v = new (test, tS, p) ;
    return (v) ;
}

#' Granger cointegrated causality test
#'
#' @param tS1 Numerical series
#' @param tS2 Numerical series
#' @param p The lag parameter
#' @details
#' @return summary () :  shows the test results
#'         F-test () : returns the value of the test

causality.test <- function(tS1,tS2, lag, differencing){
    test0 = Pred $ CausalityTest ;
    v = new (test0, tS1,tS2, lag, differencing) ;
    return (v) ;
}
